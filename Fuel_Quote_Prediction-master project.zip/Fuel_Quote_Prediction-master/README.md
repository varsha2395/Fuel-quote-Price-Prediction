# Fuel_Quote_Prediction
Suggests a fuel quote based on  specific parameters
Files related to Login page
Login Module:              login.php,
styles:                    test_style.css,
JS validations:            valid.js,
Backend validation:        server.php

Files related to Signup Module:
Signup Module:              signup.php,
style:                      test_style.css,
JS Validation:              valid.js,
Backend validation:         signup_server.php

Files related to Client Profile Registration:
Profile Module:             profile_test.php,
style:                      test_profilestyle.css,
JS Validation:              init.js,
Backend validation:         profile_server.php

Files related to Fuel Quote Module:
Fuel Quote Module:          FUELQUOTE.php,
Quote History:              quotehistory.php,
style:                      quoteStyle.css,
JS Validation:              quote.js,
Backend validation:         QUOTESERVER.php
